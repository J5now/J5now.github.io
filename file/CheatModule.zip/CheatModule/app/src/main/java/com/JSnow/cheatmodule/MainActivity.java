package com.JSnow.cheatmodule;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    public void openApp() {
        Intent intent = new Intent();
        ComponentName cn = new ComponentName("com.pangbai.projectm", "com.pangbai.projectm.MainActivity");
        intent.setComponent(cn);
        startActivity(intent);
    }
    String[] btnState = new String[]{"Start", "End"};

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn_option = findViewById(R.id.button);
        btn_option.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(btn_option.getText().equals(btnState[0])){
                    btn_option.setText(btnState[1]);
                    openApp();
                }else {
                    btn_option.setText(btnState[0]);
                    // 逻辑是空的，别看了喵

                }

            }
        });
    }
}