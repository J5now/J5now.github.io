package com.JSnow.cheatmodule;


import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class XposedCheatModule implements IXposedHookLoadPackage {
    static int state;
    static Object player;
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {
        if(loadPackageParam.packageName.equals("com.pangbai.projectm")){

            XposedHelpers.findAndHookMethod("net.osaris.turbofly.InGame", loadPackageParam.classLoader, "drawFrame", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    player = XposedHelpers.getObjectField(param.thisObject, "player");
                    XposedBridge.log("player：" + player);
                    XposedBridge.log("player vzb：" + XposedHelpers.getObjectField(player, "vzb"));
                    if(state == 1){
                        XposedHelpers.setObjectField(player, "vzb", 2.0f);
                        XposedHelpers.setObjectField(param.thisObject, "scoreInfini", (int)666666);
                    }
                    XposedBridge.log("player vzb：" + XposedHelpers.getObjectField(player, "vzb"));
                }
            });

            XposedHelpers.findAndHookMethod("net.osaris.turbofly.InGame", loadPackageParam.classLoader, "getState", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    // 监听游戏状态
                    if(state != (int)param.getResult() && state <= 3) {
                        state = (int) param.getResult();
                        XposedBridge.log("State：" + state);
                    }
                }
            });
        }


    }
}
